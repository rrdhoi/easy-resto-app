import Foundation

class AppConstants {
    static let baseUrl = "https://restaurant-api.dicoding.dev"
    static let moveToDetail = "moveToDetail"
    static let moveToProfile = "moveToProfile"
    static let baseImageMediumUrl = "https://restaurant-api.dicoding.dev/images/medium/"
}
